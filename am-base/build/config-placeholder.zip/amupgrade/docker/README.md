# File-based Configuration Transformation Tool

## Description
Transforms file-based configuration that is mounted at `/am-config` 
with the directory structure `/am-config/config/services`.

## Usages
By default the configuration mounted at `/am-config` will be upgraded using the rules
to bring the configuration inline with the current commit of AM.

### Upgrading File-based configuration
Run the following command to upgrade the configuration to the latest AM version:

`docker run --rm -v /path/to/am/config:/am-config gcr.io/forgerock-io/am-config-upgrader:latest`

### Providing custom rules
Run the following command to execute custome rules: (Note: this overwrites the provided upgrade rules files)

`docker run --rm -v /path/to/am/config:/am-config -v /path/to/custom/rules:/rules
 gcr.io/forgerock-io/am-config-upgrader:latest`

